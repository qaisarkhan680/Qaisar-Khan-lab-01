public class Int {
    int value;

    public Int() {
        value = 0;
    }

    public Int(int v) {
        value = v;
    }

    public void display() {
        System.out.println("Value = " + value);
    }

    public static void main(String[] args) {
        Int i1 = new Int();
        i1.display();

        Int i2 = new Int(25);
        i2.display();
    }
}
