import java.util.Scanner;

public class Time {
    int hours, minutes, seconds;

    public void read() {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter hours: ");
        hours = input.nextInt();

        System.out.print("Enter minutes: ");
        minutes = input.nextInt();

        System.out.print("Enter seconds: ");
        seconds = input.nextInt();
    }

    public void display24() {
        System.out.println("24-hour format: " + hours + ":" + minutes + ":" + seconds);
    }

    public void display12() {
        int h = hours % 12;
        if (h == 0) h = 12;

        String ampm = (hours >= 12) ? "PM" : "AM";

        System.out.println("12-hour format: " + h + ":" + minutes + ":" + seconds + " " + ampm);
    }

    public static void main(String[] args) {
        Time t = new Time();
        t.read();
        t.display24();
        t.display12();
    }
}
