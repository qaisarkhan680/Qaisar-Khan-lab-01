import java.util.Date;

public class TestDate {
    public static void main(String[] args) {
        long[] times = {
                10000,
                100000,
                1000000,
                10000000,
                100000000,
                1000000000L,
                10000000000L,
                100000000000L
        };

        for (long t : times) {
            Date d = new Date(t);
            System.out.println(d.toString());
        }
    }
}
