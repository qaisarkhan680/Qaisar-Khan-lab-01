public class CounterClass2 {
    static int count = 0;

    public CounterClass2() {
        count++;
        System.out.println("I am object no. " + count);
    }

    public static void main(String[] args) {
        new CounterClass2();
        new CounterClass2();
        new CounterClass2();
    }
}
