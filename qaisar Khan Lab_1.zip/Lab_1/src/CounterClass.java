public class CounterClass {

    public CounterClass() {
        System.out.println("I am object no. __");
    }

    public static void main(String[] args) {
        new CounterClass();
        new CounterClass();
        new CounterClass();
    }
}
