import java.util.Scanner;

public class Marks {
    int m1, m2, m3;

    public void set_marks() {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter mark 1: ");
        m1 = input.nextInt();
        System.out.print("Enter mark 2: ");
        m2 = input.nextInt();
        System.out.print("Enter mark 3: ");
        m3 = input.nextInt();
    }

    public int sum() {
        return m1 + m2 + m3;
    }

    public double avg() {
        return sum() / 3.0;
    }

    public static void main(String[] args) {
        Marks m = new Marks();
        m.set_marks();
        System.out.println("Sum = " + m.sum());
        System.out.println("Average = " + m.avg());
    }
}
