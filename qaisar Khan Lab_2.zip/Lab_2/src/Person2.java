import java.util.Scanner;

public class Person2 {
    long id;  // <-- change from int to long
    String name;
    String address;

    public void input() {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter ID: ");
        id = s.nextLong(); // <-- change nextInt() to nextLong()
        s.nextLine();
        System.out.print("Enter Name: ");
        name = s.nextLine();
        System.out.print("Enter Address: ");
        address = s.nextLine();
    }

    public void display() {
        System.out.println(id + " | " + name + " | " + address);
    }
}
