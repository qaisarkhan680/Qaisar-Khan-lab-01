public class MyDate {
    int day, month, year;

    public MyDate(int d, int m, int y) {
        day = d;
        month = m;
        year = y;
    }
}
