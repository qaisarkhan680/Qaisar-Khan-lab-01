import java.util.Scanner;

public class Publication {
    String title;
    double price;

    public void getdata() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Title: ");
        title = sc.nextLine();
        System.out.print("Enter Price: ");
        price = sc.nextDouble();
    }

    public void putdata() {
        System.out.println("Title: " + title);
        System.out.println("Price: " + price);
    }
}
