
import java.util.Scanner; // <-- Add this

public class Student extends Person2 {
    int rollNumber;
    double marks;

    @Override
    public void input() {
        super.input();
        Scanner s = new Scanner(System.in);
        System.out.print("Enter Roll Number: ");
        rollNumber = s.nextInt();
        System.out.print("Enter Marks: ");
        marks = s.nextDouble();
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Roll: " + rollNumber + ", Marks: " + marks);
    }

    public static void main(String[] args) {
        Student s = new Student();
        s.input();
        s.display();
    }
}
