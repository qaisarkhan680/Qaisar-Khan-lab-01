public class Laptop extends Computer {
    double length, width, height, weight;

    public Laptop(int w, int m, int s, double sp,
                  double l, double wd, double h, double wt) {
        super(w, m, s, sp);
        length = l;
        width = wd;
        height = h;
        weight = wt;
    }

    public void display() {
        super.display();
        System.out.println("Length: " + length);
        System.out.println("Width: " + width);
        System.out.println("Height: " + height);
        System.out.println("Weight: " + weight);
    }

    public static void main(String[] args) {
        Laptop l = new Laptop(64, 8000, 512000, 3200,
                14, 9, 0.7, 1.8);
        l.display();
    }
}
