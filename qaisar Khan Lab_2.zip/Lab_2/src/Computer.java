public class Computer {
    int wordsize;
    int memorysize;
    int storagesize;
    double speed;

    public Computer() {}

    public Computer(int w, int m, int s, double sp) {
        wordsize = w;
        memorysize = m;
        storagesize = s;
        speed = sp;
    }

    public void display() {
        System.out.println("Word size: " + wordsize);
        System.out.println("Memory: " + memorysize);
        System.out.println("Storage: " + storagesize);
        System.out.println("Speed: " + speed + "MHz");
    }
}
