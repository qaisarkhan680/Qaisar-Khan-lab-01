public class Address {
    private String street;
    private String house;
    private String city;
    private String code;

    public Address() {}

    public Address(String street, String house, String city, String code) {
        this.street = street;
        this.house = house;
        this.city = city;
        this.code = code;
    }

    public String getStreet() { return street; }
    public String getHouse() { return house; }
    public String getCity() { return city; }
    public String getCode() { return code; }

    public void setStreet(String street) { this.street = street; }
    public void setHouse(String house) { this.house = house; }
    public void setCity(String city) { this.city = city; }
    public void setCode(String code) { this.code = code; }
}
