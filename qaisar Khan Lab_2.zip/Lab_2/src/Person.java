public class Person {
    private String name;
    private Address address;

    public Person(String name, Address address) {
        this.name = name;
        this.address = address;
    }

    public void display() {
        System.out.println("Name: " + name);
        System.out.println("Address: " + address.getHouse() + ", " + address.getStreet() +
                ", " + address.getCity() + " - " + address.getCode());
    }

    public static void main(String[] args) {
        Address a = new Address("Street 12", "House 44", "Lahore", "54000");
        Person p = new Person("Ali", a);
        p.display();
    }
}
