public class Book extends Publication {
    int pageCount;

    public void getdata() {
        super.getdata();
        System.out.print("Enter Page Count: ");
        pageCount = new java.util.Scanner(System.in).nextInt();
    }

    public void putdata() {
        super.putdata();
        System.out.println("Pages: " + pageCount);
    }
}
