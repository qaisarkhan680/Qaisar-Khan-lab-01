public class Employee {
    String name;
    MyDate joiningDate;
    MyDate birthDate;

    public Employee(String name, MyDate joining, MyDate birth) {
        this.name = name;
        this.joiningDate = joining;
        this.birthDate = birth;
    }

    public boolean joinedWithinFiveYears(int currentYear) {
        return (currentYear - joiningDate.year) <= 5;
    }

    public boolean ageLessThan40(int currentYear) {
        return (currentYear - birthDate.year) < 40;
    }

    public static void main(String[] args) {
        Employee e = new Employee(
                "Ali",
                new MyDate(10, 5, 2010),
                new MyDate(20, 3, 1980)
        );

        System.out.println("Joined within 5 years? " + e.joinedWithinFiveYears(2012));
        System.out.println("Age less than 40? " + e.ageLessThan40(2012));
    }
}
