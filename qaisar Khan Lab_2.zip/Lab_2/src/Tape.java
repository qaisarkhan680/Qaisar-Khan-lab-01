public class Tape extends Publication {
    int minutes;

    public void getdata() {
        super.getdata();
        System.out.print("Enter Playing Time: ");
        minutes = new java.util.Scanner(System.in).nextInt();
    }

    public void putdata() {
        super.putdata();
        System.out.println("Time: " + minutes + " minutes");
    }
}
