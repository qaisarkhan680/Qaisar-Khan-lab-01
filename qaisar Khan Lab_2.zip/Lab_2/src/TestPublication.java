public class TestPublication {
    public static void main(String[] args) {
        Book b = new Book();
        Tape t = new Tape();

        System.out.println("Enter Book Data:");
        b.getdata();

        System.out.println("\nEnter Tape Data:");
        t.getdata();

        System.out.println("\nBook Details:");
        b.putdata();

        System.out.println("\nTape Details:");
        t.putdata();
    }
}
